package students.exercise2;

import java.security.SecureRandom;

import students.IGroupElement;
import students.elgamal.ElgamalCiphertext;
import students.exercise2.CandidateMessagePair;
import students.exercise2.DDHChallenge;
import students.exercise2.IDDHIndCPAElgamalReduction;
import students.exercise2.IElgamalIndCPAAdversary;

/**
 * Implement your solution to Exercise 2 in this class.
 */
public class Solution2 implements IDDHIndCPAElgamalReduction {

    @Override
    public boolean decideDDH(DDHChallenge ddhChallenge, IElgamalIndCPAAdversary adversary) {
        /**
         * Implement your solution here. You need to decide whether z = x * y, where g,
         * g^x, g^y and g^z are determined by ddhChallenge.
         * 
         * You can use adversary for deciding this. Note, that your reduction must be
         * TIGHT. This means, you may call the method
         * adversary.solveIndCPAChallenge(ciphertext) at most once.
         */
         
        IGroupElement generator = ddhChallenge.generator; 
        IGroupElement pk = ddhChallenge.groupElementX;
        ElgamalCiphertext c = new ElgamalCiphertext(); 
        c.c0 = ddhChallenge.groupElementY;
        
        adversary.init(generator,pk);
        CandidateMessagePair<IGroupElement> cand_msg = adversary.getCandidateMessages();
        IGroupElement Z = ddhChallenge.groupElementZ; 

        SecureRandom RNG = new SecureRandom();
        int b = RNG.nextInt(2);
        if (b == 0){
          c.c1 = Z.multiply(cand_msg.Message0);
        }else{
          c.c1 = Z.multiply(cand_msg.Message1);
        }
        
        int b1 = adversary.solveIndCPAChallenge(c);
        
        if (b1 == b){
          return true;
        }else{
          return false;
        }

        /**
         * You need to return here true iff ddhChallenge was honestly generated. I.e.
         * iff z = x * y, then you must return true here. Otherwise, you must return
         * false.
         */
    }
}
