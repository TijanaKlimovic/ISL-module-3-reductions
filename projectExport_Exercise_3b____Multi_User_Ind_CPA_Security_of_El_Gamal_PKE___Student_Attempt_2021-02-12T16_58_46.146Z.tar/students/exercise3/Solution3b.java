package students.exercise3;

import java.security.SecureRandom;

import students.IGroupElement;
import students.elgamal.ElgamalCiphertext;
import students.exercise2.CandidateMessagePair;
import students.exercise2.DDHChallenge;
import students.exercise3.IElgamalMultiUserIndCPAAdversary;

/**
 * Implement your solutions to Exercise 3.b) in this class.
 */
public class Solution3b implements IDDHMultiUserIndCPAElgamalReduction {
    @Override
    public boolean decideDDH(DDHChallenge ddhChallenge, IElgamalMultiUserIndCPAAdversary adversary,
            IRerandomizationOracle rerandomizationOracle) {
        /**
         * Implement your solution here. You need to decide whether z = x * y, where g,
         * g^x, g^y and g^z are determined by ddhChallenge.
         * 
         * You can use adversary for deciding this. Note, that your reduction must be
         * TIGHT. This means, you may call the method
         * adversary.solveIndCPAChallenge(ciphertexts) at most once.
         * 
         * IMPORTANT: Make sure that the public keys given to the adversary come from
         * the DDH challenges rerandomized by rerandomizationOracle! Look up the
         * documentation of adversary and rerandomizationOracle for more details!
         */
        int users = adversary.getNumberUsers();
        DDHChallenge[] DDHs = rerandomizationOracle.rerandomizeChallenge(users, ddhChallenge);
        IGroupElement[] pks = new IGroupElement[users];
        
        for (int i=0; i < users; i++) {
          pks[i] = DDHs[i].groupElementX;
        }
         
        IGroupElement generator = ddhChallenge.generator; 
        adversary.init(generator,pks);
        CandidateMessagePair<IGroupElement>[] cand_msgs = adversary.getCandidateMessages();
        ElgamalCiphertext[] ciphertexts = new ElgamalCiphertext[users];
        
        SecureRandom RNG = new SecureRandom();
        int b = RNG.nextInt(2);
        
        if (b == 0){
          for (int i=0; i < users; i++) {
          ciphertexts[i] = new ElgamalCiphertext();
          ciphertexts[i].c0 = DDHs[i].groupElementY;
          ciphertexts[i].c1 = DDHs[i].groupElementZ.multiply(cand_msgs[i].Message0);
          }
        }else{
          for (int i=0; i < users; i++) {
          ciphertexts[i] = new ElgamalCiphertext();
          ciphertexts[i].c0 = DDHs[i].groupElementY;
          ciphertexts[i].c1 = DDHs[i].groupElementZ.multiply(cand_msgs[i].Message1);
          }
        }
        
        int b1 = adversary.solveIndCPAChallenge(ciphertexts);
        
        if (b1 == b){
          return true;
        }else{
          return false;
        }
         
         

        /**
         * You can use the randomness of this random number generator.
         */
        //SecureRandom RNG = new SecureRandom();

        /**
         * You need to return here true iff ddhChallenge was honestly generated. I.e.,
         * if z = x * y, then you must return true here. Otherwise, you must return
         * false.
         */
    }

}
