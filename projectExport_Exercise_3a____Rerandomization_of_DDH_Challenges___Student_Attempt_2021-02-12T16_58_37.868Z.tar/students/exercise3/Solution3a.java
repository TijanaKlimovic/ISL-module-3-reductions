package students.exercise3;

import java.security.SecureRandom;
import java.math.BigInteger;

import students.exercise2.DDHChallenge;
import students.exercise3.IDDHRerandomizer;

import students.IGroupElement;

/**
 * You can use this method in Exercise 3.a.
 */
import static students.Helper.getRandomBigInteger;

/**
 * Implement your solutions to Exercise 3.a in this class.
 */
public class Solution3a implements IDDHRerandomizer {
    @Override
    public DDHChallenge[] rerandomize(int numberOfGames, DDHChallenge ddhChallenge, SecureRandom RNG) {
        /**
         * Implement your solution to Exercise 3.1 here.
         */
        BigInteger order = ddhChallenge.generator.getGroupOrder();
        DDHChallenge[] rerandomizedChallenges = new DDHChallenge[numberOfGames];
        
        for (int i=0; i < numberOfGames; i++) {
          
          rerandomizedChallenges[i] = new DDHChallenge();
          rerandomizedChallenges[i].generator = ddhChallenge.generator; //  maybe need to do generator.clone()? 
          
          BigInteger r1 = getRandomBigInteger(RNG, order);
          BigInteger r2 = getRandomBigInteger(RNG, order);
          BigInteger r3 = getRandomBigInteger(RNG, order);
          BigInteger r4 = getRandomBigInteger(RNG, order);
          
          IGroupElement D = ddhChallenge.generator.power(r2);
          IGroupElement E = ddhChallenge.generator.power(r4);
          rerandomizedChallenges[i].groupElementX = ddhChallenge.groupElementX.power(r1);
          rerandomizedChallenges[i].groupElementY = ddhChallenge.groupElementY.power(r3);
        
          rerandomizedChallenges[i].groupElementX = rerandomizedChallenges[i].groupElementX.multiply(D);
          rerandomizedChallenges[i].groupElementY = rerandomizedChallenges[i].groupElementY.multiply(E);
          
          IGroupElement r2r4 = D.power(r4);
          IGroupElement xr1r4  = ddhChallenge.groupElementX.power(r1);
          xr1r4  = xr1r4.power(r4);
          
          IGroupElement yr2r3  = ddhChallenge.groupElementY.power(r2);
          yr2r3 = yr2r3.power(r3);
          
          rerandomizedChallenges[i].groupElementZ = ddhChallenge.groupElementZ.power(r1);
          rerandomizedChallenges[i].groupElementZ = rerandomizedChallenges[i].groupElementZ.power(r3);
          rerandomizedChallenges[i].groupElementZ = rerandomizedChallenges[i].groupElementZ.multiply(r2r4);
          rerandomizedChallenges[i].groupElementZ = rerandomizedChallenges[i].groupElementZ.multiply(xr1r4);
          rerandomizedChallenges[i].groupElementZ = rerandomizedChallenges[i].groupElementZ.multiply(yr2r3);
          //rerandomizedChallenges[i].groupElementZ = ddhChallenge.groupElementZ.multiply(r1r2);
          //rerandomizedChallenges[i].groupElementZ = rerandomizedChallenges[i].groupElementZ.multiply(xr2);
          //rerandomizedChallenges[i].groupElementZ = rerandomizedChallenges[i].groupElementZ.multiply(yr1);
        }
        
        

        
        
        /**
         * You need to rerandomize ddhChallenge. Use for this task, the randomness from
         * RNG. Don't use any other randomness.
         */

        /**
         * You must return here an array of DDH Challenges (g, g^(d_1), g^(e_1),
         * g^(f_1)), ..., (g, g^(d_n), g^(e_n), g^(f_n)) s.t. we have for each i = 1,
         * ..., n:
         * 
         * (g, g^(d_i), g^(e_i), g^(f_i)) is honestly generated, if (g, g^x, g^y, g^z)
         * was honestly generated. If z =/= x * y, then g^(f_i) must be sampled
         * uniformly at random from the group and independently from g^(d_i) and
         * g^(e_i).
         * 
         * In each case, g^(d_i) and g^(e_i) must be sampled uniformly and independently
         * at random from the group.
         */
        return rerandomizedChallenges;
    }

}