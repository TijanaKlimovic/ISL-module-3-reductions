package students.exercise1;

import students.IGroupElement;
import students.elgamal.ElgamalCiphertext;
import students.exercise1.CDHChallenge;
import students.exercise1.ICDHOwCPAElgamalReduction;
import students.exercise1.IElgamalOwCPAAdversary;

import java.math.BigInteger;
import java.security.SecureRandom;

import static students.Helper.getRandomBigInteger;

/**
 * You can use this method.
 */
import static students.Helper.getRandomBigInteger;

/**
 * Implement your solution to Exercise 1 in this class.
 */
public class Solution1 implements ICDHOwCPAElgamalReduction {

    @Override
    public IGroupElement solveCDH(CDHChallenge cdhChallenge, IElgamalOwCPAAdversary adversary) {

        /**
         * Implement your solution here. You need to compute g^(x*y), where g, g^x and
         * g^y are determined by cdhChallenge.
         * 
         * You can use adversary for computing g^(xy). Note, that your reduction must be
         * TIGHT. This means, you may call the method
         * adversary.extractMessage(ciphertext) at most once and your solution must
         * succeed whenever the adversary succeeds.
         */

        /**
         * You can use the randomness of this random number generator.
         */

        IGroupElement generator = cdhChallenge.generator;
        IGroupElement pk = cdhChallenge.groupElementX;
        ElgamalCiphertext c = new ElgamalCiphertext(); 
        c.c0 = cdhChallenge.groupElementY;
        
        SecureRandom RNG = new SecureRandom();
        BigInteger r = getRandomBigInteger(RNG, generator.getGroupOrder());
        IGroupElement c1 = generator.power(r);
        
        c.c1 = c1;
        adversary.init(generator, pk);
        IGroupElement m = adversary.extractMessage(c);
        IGroupElement result = c.c1.multiply(m.invert());
        return result;
        
        /**
         * You need to return g^(xy) here.
         */
    }
}
